package sistema_de_tickes;

import Modelos.Tickets;
import Modelos.Estado;
import Modelos.Departamento;
import java.io.*;
import java.net.URL;
import java.util.*;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;

/**
 * FXML Controller class
 *
 * @author denil
 */
public class TicketController implements Initializable {

    @FXML private TextField fldTitulo;
    @FXML private Text txtDescripcion;
    private ComboBox<Departamento> cbxDepartamento;
    private ComboBox<String> cbxPrioridad;
    private ListView<String> lstAdjuntos;
    @FXML private Button btnCrear;
    private ListView<Tickets> lstTickets;
    private TextField fldNota;
    private ComboBox<Estado> cbxEstados;
    @FXML private Text txtTicket;
    @FXML private Text txtTitulo;
    @FXML private Text txtEstado;
    @FXML private Text txtFechaCreacion;
    @FXML private Text txtCreador;
    @FXML private Button btnRegresar;
    @FXML private DatePicker fldDate;
    @FXML private MenuButton BotonMenu;
    @FXML private MenuItem Usuarios;
    @FXML private MenuItem itemRoles;
    @FXML private MenuItem itemTicket;
    @FXML private MenuItem itemDepartamento;
    @FXML private MenuItem itemDetallesTicket;
    @FXML private MenuItem itemFlujoDeTrabajo;
    @FXML private MenuItem itemHistorial;
    @FXML private MenuItem itemSalir;

    private List<Tickets> tickets = new ArrayList<>();
    private List<Departamento> departamentos = new ArrayList<>();
    private List<String> adjuntosTemporales = new ArrayList<>();

    private final String ARCHIVO_TICKETS = "tickets.dat";
    private final String ARCHIVO_DEPTOS = "departamentos.dat";
    @FXML
    private TextField fldTicket;
    @FXML
    private TextField fldDescripcion;
    @FXML
    private TextField fldCreador;
    @FXML
    private ComboBox<?> CbxEsstado;
    @FXML
    private Text txtDepAsignado;
    @FXML
    private ComboBox<?> CbxEsstado1;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarDepartamentos();
        cargarTickets();

        cbxDepartamento.setItems(FXCollections.observableList(departamentos));
        cbxPrioridad.setItems(FXCollections.observableArrayList("Baja", "Media", "Alta"));
        cbxEstados.setItems(FXCollections.observableArrayList(Estado.values()));

        lstAdjuntos.setItems(FXCollections.observableList(adjuntosTemporales));
        lstTickets.setItems(FXCollections.observableList(tickets));

        lstTickets.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> mostrarDetallesTicket(newVal));
    }

    private void cargarTickets() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_TICKETS))) {
            tickets = (List<Tickets>) ois.readObject();
        } catch (Exception e) {
            tickets = new ArrayList<>();
        }
    }

    private void guardarTickets() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_TICKETS))) {
            oos.writeObject(tickets);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void cargarDepartamentos() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_DEPTOS))) {
            departamentos = (List<Departamento>) ois.readObject();
        } catch (Exception e) {
            departamentos = new ArrayList<>();
        }
    }

    private void guardarDepartamentos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_DEPTOS))) {
            oos.writeObject(departamentos);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Departamento buscarDepartamento(String nombre) {
        for (Departamento d : departamentos) {
            if (d.getNombre().equalsIgnoreCase(nombre)) {
                return d;
            }
        }
        return null;
    }

    private void adjuntarArchivo(ActionEvent ev) {
        FileChooser fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Todos los archivos", "*.*"));
        File f = fc.showOpenDialog(null);
        if (f != null) {
            adjuntosTemporales.add(f.getAbsolutePath());
            lstAdjuntos.refresh();
        }
    }

    private void crearTicket(ActionEvent ev) {
        String titulo = fldTitulo.getText().trim();
        String descripcion = txtDescripcion.getText().trim();
        Departamento departamento = cbxDepartamento.getValue();
        String prioridad = cbxPrioridad.getValue();
        String creadoPor = "admin"; // Obtener el nombre del usuario actual, si es necesario

        // Validación de campos
        if (validarCampos(titulo, descripcion, departamento)) {
            Tickets nuevoTicket = new Tickets(titulo, descripcion, departamento, prioridad, creadoPor);
            adjuntarArchivos(nuevoTicket);

            tickets.add(nuevoTicket);
            guardarTickets();
            lstTickets.getItems().add(nuevoTicket);
            mostrarAlerta("Éxito", "Ticket creado correctamente.");
            limpiarFormulario();
        }
    }

    private boolean validarCampos(String titulo, String descripcion, Departamento departamento) {
        if (titulo.length() < 3 || descripcion.length() < 3) {
            mostrarAlerta("Error", "El título y la descripción deben tener al menos 3 caracteres.");
            return false;
        }
        if (departamento == null) {
            mostrarAlerta("Error", "Debes seleccionar un departamento válido.");
            return false;
        }
        return true;
    }

    private void adjuntarArchivos(Tickets nuevoTicket) {
        for (String path : adjuntosTemporales) {
            nuevoTicket.agregarAdjunto(path);
        }
    }

    private void limpiarFormulario() {
        fldTitulo.clear();
        
        cbxDepartamento.getSelectionModel().clearSelection();
        cbxPrioridad.getSelectionModel().clearSelection();
        cbxEstados.getSelectionModel().clearSelection(); // Limpiar estado
        adjuntosTemporales.clear();
        lstAdjuntos.refresh();
        lstTickets.getSelectionModel().clearSelection(); // Limpiar lista de tickets
    }

    private void tomarTicket(ActionEvent ev) {
        Tickets sel = lstTickets.getSelectionModel().getSelectedItem();
        if (sel == null || !sel.tomarTicket("TÉCNICO")) {
            mostrarAlerta("Error", "No puede tomar ese ticket.");
            return;
        }
        guardarTickets();
        lstTickets.refresh();
    }

    private void agregarNota(ActionEvent ev) {
        Tickets sel = lstTickets.getSelectionModel().getSelectedItem();
        String nota = fldNota.getText().trim();
        if (sel == null || nota.isEmpty()) return;
        sel.agregarNota("TÉCNICO", nota);
        guardarTickets();
        fldNota.clear();
    }

    private void cambiarEstado(ActionEvent ev) {
        Tickets sel = lstTickets.getSelectionModel().getSelectedItem();
        Estado nuevo = cbxEstados.getValue();
        if (sel == null || nuevo == null) return;
        sel.cambiarEstado(nuevo, "TÉCNICO");
        guardarTickets();
        lstTickets.refresh();
    }

    public void asignarTicket(Tickets ticket, String tecnico) {
        if (!ticket.getEstado().equals(Estado.PENDIENTE)) { // Usar Enum Estado
            mostrarAlerta("Error", "Este ticket ya está asignado o no está pendiente.");
            return;
        }
        ticket.setTecnicoAsignado(tecnico);
        ticket.setEstado(Estado.EN_PROCESO); // Cambiar el estado a "En Proceso"
        ticket.agregarHistorial("Asignado a " + tecnico);
        guardarTickets();
    }

    public void cerrarTicket(Tickets ticket, String tecnico) {
        if (!tecnico.equals(ticket.getTecnicoAsignado())) {
            mostrarAlerta("Error", "Solo el técnico asignado puede cerrar este ticket.");
            return;
        }
        ticket.setEstado(Estado.CERRADO); // Cambiar el estado a "Cerrado"
        ticket.agregarHistorial("Ticket cerrado por " + tecnico);
        guardarTickets();
    }

    private void mostrarDetallesTicket(Tickets ticket) {
        if (ticket == null) return;
        txtTicket.setText("ID: " + ticket.getId());
        txtTitulo.setText(ticket.getTitulo());
        txtEstado.setText(ticket.getEstado().toString()); // Asegúrate de usar .toString() para mostrar el nombre del estado
        txtFechaCreacion.setText(ticket.getFechaCreacion().toString());
        txtCreador.setText(ticket.getCreadoPor());
    }

    private void mostrarAlerta(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    @FXML
    private void eventCrear(ActionEvent event) {
    }

    @FXML
    private void eventRegresar(ActionEvent event) {
    }

    @FXML
    private void eventUsuarios(ActionEvent event) {
    }

    @FXML
    private void eventRoles(ActionEvent event) {
    }

    @FXML
    private void eventTicket(ActionEvent event) {
    }

    @FXML
    private void eventDepartamento(ActionEvent event) {
    }

    @FXML
    private void eventDetalleTicket(ActionEvent event) {
    }

    @FXML
    private void itemFlujoDeTrabajo(ActionEvent event) {
    }

    @FXML
    private void eventHistorial(ActionEvent event) {
    }

    @FXML
    private void eventSallir(ActionEvent event) {
    }

    @FXML
    private void eventCambiarPantallla(ActionEvent event) {
    }
}