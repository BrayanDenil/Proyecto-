package Modelos;

import java.io.Serializable;
import java.util.List;

/**

 * @author denil
 */

public class Configuracion_de_sistema implements Serializable {

    private static final long serialVersionUID = 1L;

    private String nombre;
    private String logoPath;
    private String idioma;
    private String zonaHoraria;
    private int diasVencimientoTicket;
    private List<String> nivelesPrioridad;

    public Configuracion_de_sistema(String nombre, String logoPath, String idioma, String zonaHoraria,
                                    int diasVencimientoTicket, List<String> nivelesPrioridad) {
        this.nombre = nombre;
        this.logoPath = logoPath;
        this.idioma = idioma;
        this.zonaHoraria = zonaHoraria;
        this.diasVencimientoTicket = diasVencimientoTicket;
        this.nivelesPrioridad = nivelesPrioridad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLogoPath() {
        return logoPath;
    }

    public void setLogoPath(String logoPath) {
        this.logoPath = logoPath;
    }

    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }

    public String getZonaHoraria() {
        return zonaHoraria;
    }

    public void setZonaHoraria(String zonaHoraria) {
        this.zonaHoraria = zonaHoraria;
    }

    public int getDiasVencimientoTicket() {
        return diasVencimientoTicket;
    }

    public void setDiasVencimientoTicket(int diasVencimientoTicket) {
        this.diasVencimientoTicket = diasVencimientoTicket;
    }

    public List<String> getNivelesPrioridad() {
        return nivelesPrioridad;
    }

    public void setNivelesPrioridad(List<String> nivelesPrioridad) {
        this.nivelesPrioridad = nivelesPrioridad;
    }

    @Override
    public String toString() {
        return "Configuracion_de_sistema{" +
                "Nombre='" + nombre + '\'' +
                ", LogoPath='" + logoPath + '\'' +
                ", Idioma='" + idioma + '\'' +
                ", ZonaHoraria='" + zonaHoraria + '\'' +
                ", DiasVencimientoTicket=" + diasVencimientoTicket +
                ", NivelesPrioridad=" + nivelesPrioridad +
                '}';
    }
}