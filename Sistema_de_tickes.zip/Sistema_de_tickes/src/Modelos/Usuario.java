package Modelos;

import java.util.logging.Logger;

/**
 * Autor: denil
 */

public class Usuario extends Persona {

    private String departamento;

    
    public Usuario(String codigoUsuario, String nombre, String apellido, String correo, 
                   String contraseña, String telefono, String rol, String area, 
                   String ingreso, String departamento) {
  
        super(codigoUsuario, nombre, apellido, correo, contraseña, telefono, rol, area, ingreso);
        
      
        this.departamento = departamento;
    }

   
    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    @Override
    public String toString() {
        return "Usuario{" + "departamento=" + departamento + '}';
        
    }
    public String obtenerNombreCompleto(){
    
    return getNombre()+""+ getApellido();
    
    }
    
    
}
