package Modelos;

import java.io.Serializable;
import java.util.List;

/**
 * 
 * 
 * @author denil
 */
public class Estado_Ticket implements Serializable {

    private static final long serialVersionUID = 1L;

    private String nombre;
    private String descripcion;
    private boolean esFinal;
    private List<String> estadosSiguientes;

    public Estado_Ticket(String nombre, String descripcion, boolean esFinal, List<String> estadosSiguientes) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.esFinal = esFinal;
        this.estadosSiguientes = estadosSiguientes;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public boolean isEsFinal() {
        return esFinal;
    }

    public void setEsFinal(boolean esFinal) {
        this.esFinal = esFinal;
    }

    public List<String> getEstadosSiguientes() {
        return estadosSiguientes;
    }

    public void setEstadosSiguientes(List<String> estadosSiguientes) {
        this.estadosSiguientes = estadosSiguientes;
    }

    @Override
    public String toString() {
        return "Estado_Ticket{" +
                "nombre='" + nombre + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", esFinal=" + esFinal +
                ", estadosSiguientes=" + estadosSiguientes +
                '}';
    }
}