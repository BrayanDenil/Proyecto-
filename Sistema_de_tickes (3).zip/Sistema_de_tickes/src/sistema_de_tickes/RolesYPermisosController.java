package sistema_de_tickes;

import Modelos.RolesYPermiso;
import Modelos.Permiso;
import Modelos.Usuario;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class RolesYPermisosController implements Initializable {

    private List<RolesYPermiso> roles = new ArrayList<>();
    private ObservableList<Usuario> listaUsuarios = FXCollections.observableArrayList(); // Lista de usuarios

    private ListView<String> listaRolesYPermiso;

    @FXML
    private Text txtPermisos;

    @FXML
    private TextField fldPermisos;

    @FXML
    private Button btnCrear;

    @FXML
    private Button btnEliminar;

    @FXML
    private Button bltRegresar;

    @FXML
    private Text txtNombre;

    @FXML
    private Text txfDescripcion;

    @FXML
    private TextField fldDescripcion;

    @FXML
    private ComboBox<Usuario> cmbox;

    @FXML
    private Button btnHistorial;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cargarUsuarios(); // Llenar el ComboBox con usuarios
        cargarRoles(); // Cargar los roles guardados
        actualizarListaRoles(); // Actualizar la lista de roles en la interfaz

        // Mostrar detalles del rol cuando se hace clic en un rol
        listaRolesYPermiso.setOnMouseClicked(event -> {
            String seleccionado = listaRolesYPermiso.getSelectionModel().getSelectedItem();
            RolesYPermiso rol = roles.stream()
                    .filter(r -> r.getNombre().equals(seleccionado))
                    .findFirst()
                    .orElse(null);
            if (rol != null) {
                txfDescripcion.setText("Descripción: " + rol.getDescripcion());
                txtPermisos.setText("Permisos: " + rol.getPermisos().stream()
                        .map(Permiso::getNombre)
                        .collect(Collectors.joining(", ")));
            }
        });
    }
    
    private void cargarUsuarios() {

        
         listaUsuarios.add(new Usuario("001", "admin", "Admin", "admin@correo.com", "admin123", "1234567890", "Administrador", "TI", "2023-01-01", "TI"));
          listaUsuarios.add(new Usuario("002", "tecnico", "Tecnico", "tecnico@correo.com", "tecnico123", "0987654321", "Técnico", "Soporte", "2022-01-01", "Soporte"));
          listaUsuarios.add(new Usuario("003", "cliente", "Cliente", "cliente@correo.com", "cliente123", "1122334455", "Cliente", "Ventas", "2021-01-01", "Ventas"));

        cmbox.setItems(listaUsuarios);  
    }

    // Método para cargar los roles guardados
    private void cargarRoles() {
        // Aquí se debe cargar los roles desde un archivo o base de datos
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("roles.dat"))) {
            roles = (List<RolesYPermiso>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            // Si no se pueden cargar los roles, continuar con la lista vacía
            System.out.println("No se pudieron cargar los roles.");
        }
    }

    // Método para guardar los roles en un archivo
    private void guardarRoles() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("roles.dat"))) {
            oos.writeObject(roles);
        } catch (IOException e) {
            System.out.println("No se pudieron guardar los roles.");
        }
    }

    // Crear un nuevo rol
    @FXML
    private void eventCreaRol(ActionEvent event) {
        Usuario usuarioSeleccionado = cmbox.getValue();
        String descripcion = fldDescripcion.getText().trim();
        String nombreRol = fldPermisos.getText().trim();  // Se obtiene el nombre del rol desde el campo

        // Validar que se haya seleccionado un usuario
        if (usuarioSeleccionado == null) {
            mostrarAlerta("Nombre inválido", "Debe seleccionar un usuario para asociar un rol.");
            return;
        }

        // Validar nombre del rol
        if (nombreRol.length() < 3 || nombreRol.length() > 50) {
            mostrarAlerta("Nombre inválido", "El nombre del rol debe tener entre 3 y 50 caracteres.");
            return;
        }

        // Validar que no exista un rol con el mismo nombre
        boolean existe = roles.stream().anyMatch(r -> r.getNombre().equalsIgnoreCase(nombreRol));
        if (existe) {
            mostrarAlerta("Duplicado", "Ya existe un rol con ese nombre.");
            return;
        }

        // Crear el nuevo rol
        RolesYPermiso nuevoRol = new RolesYPermiso(nombreRol, descripcion);

        // Crear permisos por defecto
        Permiso permisoVerTickets = new Permiso("Ver tickets", "Permite ver los tickets creados.");
        Permiso permisoCrearTickets = new Permiso("Crear tickets", "Permite crear nuevos tickets.");

        // Asignar permisos al rol
        nuevoRol.agregarPermiso(permisoVerTickets);
        nuevoRol.agregarPermiso(permisoCrearTickets);

        // Añadir el nuevo rol a la lista de roles
        roles.add(nuevoRol);

        // Registrar el cambio en el historial
        registrarCambio(usuarioSeleccionado.getNombre(), "Creó el rol con permisos básicos.");

        // Actualizar la lista de roles en la interfaz
        actualizarListaRoles();

        // Guardar los roles actualizados
        guardarRoles();

        // Limpiar los campos de entrada
        limpiarCampos();
    }

    // Eliminar un rol
    @FXML
    private void eventEliminar(ActionEvent event) {
        String seleccionado = listaRolesYPermiso.getSelectionModel().getSelectedItem();
        if (seleccionado != null) {
            // Buscar y eliminar el rol de la lista
            RolesYPermiso rolAEliminar = roles.stream()
                .filter(rol -> rol.getNombre().equals(seleccionado))
                .findFirst()
                .orElse(null);

            if (rolAEliminar != null) {
                roles.remove(rolAEliminar);
                registrarCambio(rolAEliminar.getNombre(), "Eliminó el rol.");
                actualizarListaRoles();

                // Guardar los roles actualizados
                guardarRoles();
            }
        } else {
            mostrarAlerta("Selección requerida", "Debe seleccionar un rol de la lista para eliminar.");
        }
    }

    // Regresar al menú principal
    @FXML
    private void eventRegresar(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/Menu Principal.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) bltRegresar.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Ver historial de cambios
    @FXML
    private void eventHistorial(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Graficos/Historial1.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) btnHistorial.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Métodos auxiliares
    private void actualizarListaRoles() {
        listaRolesYPermiso.getItems().clear();
        for (RolesYPermiso rol : roles) {
            listaRolesYPermiso.getItems().add(rol.getNombre());
        }
    }

    private void limpiarCampos() {
        cmbox.getSelectionModel().clearSelection();
        fldDescripcion.clear();
        fldPermisos.clear();  // Limpiar el campo de nombre del rol
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    // Registrar un cambio en el historial de cambios
    public static void registrarCambio(String usuario, String accion) {
        try (FileWriter fw = new FileWriter("historial_cambios.log", true);
             PrintWriter pw = new PrintWriter(fw)) {
            pw.println(LocalDateTime.now() + " - Usuario: " + usuario + " - Acción: " + accion);
        } catch (IOException e) {
            System.out.println("No se pudo registrar el historial.");
        }
    }
}
