package Modelos;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;


/**
 * 
 * 
 * @author denil
 */



public class Persona implements Serializable {
    private String codigoUsuario;
    private String nombre;
    private String apellido;
    private String correo;
    private String contraseña;
    private String telefono;
    private String rol;
    private String area;
    private LocalDate ingreso;

    public Persona(String codigoUsuario, String nombre, String apellido, String correo,
                   String contraseña, String telefono, String rol, String area, String ingresoStr) {

        if (codigoUsuario == null || nombre == null || apellido == null || correo == null || contraseña == null) {
            throw new IllegalArgumentException("Ningún campo obligatorio puede ser nulo.");
        }

        this.codigoUsuario = codigoUsuario;
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.contraseña = contraseña;
        this.telefono = telefono;
        this.rol = rol;
        this.area = area;

        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            this.ingreso = LocalDate.parse(ingresoStr, formatter);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Fecha de ingreso inválida. Formato esperado: yyyy-MM-dd", e);
        }
    }

    public String getCodigoUsuario() {
        return codigoUsuario;
    }

    public void setCodigoUsuario(String codigoUsuario) {
        this.codigoUsuario = codigoUsuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public LocalDate getIngreso() {
        return ingreso;
    }

    public void setIngreso(LocalDate ingreso) {
        this.ingreso = ingreso;
    }



    @Override
    public String toString() {
        return "Persona{" +
                "codigoUsuario='" + codigoUsuario + '\'' +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", correo='" + correo + '\'' +
                ", teléfono='" + telefono + '\'' +
                ", rol='" + rol + '\'' +
                ", area='" + area + '\'' +
                ", ingreso=" + ingreso +
                '}';
    }
}