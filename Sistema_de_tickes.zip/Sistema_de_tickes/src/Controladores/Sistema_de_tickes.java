package Controladores;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Sistema_de_tickes extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        Parent root;
        try {
            root = FXMLLoader.load(getClass().getResource("/Graficos/Login.fxml"));
            if (root == null) {
                System.err.println("El archivo FXML /Graficos/Login.fxml no se encontró.");
                return;
            }
        } catch (Exception e) {
            System.err.println("Error cargando el archivo FXML: /Graficos/Login.fxml");
            e.printStackTrace();
            return;
        }

        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Sistema de Tickets");
        stage.show();
    }

    public static void main(String[] args) {
        launch(args); 
    }
}
