
package Modelos;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * 
 * 
 * @author denil
 */
public class HistorialCambios {

    private String usuario;
    private LocalDateTime fechaHora;
    private String accion;
    private String detalles;

    public HistorialCambios(String usuario, String accion, String detalles) {
        this.usuario = usuario;
        this.fechaHora = LocalDateTime.now();
        this.accion = accion;
        this.detalles = detalles;
    }

    public String getRegistroCompleto() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return "[" + fechaHora.format(formatter) + "] Usuario: " + usuario + " - " + accion + "\nDetalles: " + detalles;
    }

    // Getters

    public String getUsuario() {
        return usuario;
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }

    public String getAccion() {
        return accion;
    }

    public String getDetalles() {
        return detalles;
    }

public HistorialCambios(String usuario, LocalDateTime fechaHora, String accion, String detalles) {
    this.usuario = usuario;
    this.fechaHora = (fechaHora != null) ? fechaHora : LocalDateTime.now();
    this.accion = accion;
    this.detalles = detalles;
}

    @Override
    public String toString() {
        return "HistorialCambios{" + "usuario=" + usuario + ","
                + " fechaHora=" + fechaHora + ", "
                + "accion=" + accion + ", "
                + "detalles=" + detalles + '}';
    }


}