package Modelos;

import java.io.Serializable;

/**
 * 
 * 
 * @author denil
 */


public class Permiso implements Serializable {
    private String nombre;
    private String descripcion;

    public Permiso(String nombre, String descripcion) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del permiso no puede estar vacío.");
        }
        this.nombre = nombre;
        this.descripcion = (descripcion != null) ? descripcion : "";
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del permiso no puede estar vacío.");
        }
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = (descripcion != null) ? descripcion : "";
    }

    @Override
    public String toString() {
        return "Permiso{" + "nombre=" + nombre + ","
                + " descripcion=" + descripcion + '}';
    }

  
    }
