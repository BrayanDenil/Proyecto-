package Modelos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * 
 * 
 * @author denil
 */
public class Departamento implements Serializable {

    private static final long serialVersionUID = 1L;

    private String nombre;
    private String descripcion;
    private List<Tecnico> tecnicoAsignados;
    private Queue<Tickets> colaAtencion;
    private String soporte_Tecnico;

    public Departamento(String nombre, String descripcion,String soporte_Tecnico) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.colaAtencion = new LinkedList<>();
        this.tecnicoAsignados = new ArrayList<>();
        this.soporte_Tecnico = soporte_Tecnico;

    }

    public Departamento(String nombre, String descripcion) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Departamento(String soporte_Tecnico) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public List<Tecnico> getTecnicoAsignados() {
        return tecnicoAsignados;
    }

    public void setTecnicoAsignados(List<Tecnico> tecnicoAsignados) {
        this.tecnicoAsignados = tecnicoAsignados;
    }

    public Queue<Tickets> getColaAtencion() {
        return colaAtencion;
    }

    public void setColaAtencion(Queue<Tickets> colaAtencion) {
        this.colaAtencion = colaAtencion;
    }

    /**
     * Agrega un ticket a la cola de atención del departamento.
     */
    public void agregarTicket(Tickets nuevoTicket) {
        colaAtencion.add(nuevoTicket);
    }
    
    

    @Override
    public String toString() {
        return "Departamento{" +
                "nombre='" + nombre + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", tecnicoAsignados=" + tecnicoAsignados +
                ", colaAtencion=" + colaAtencion +
                '}';
    }

    public boolean equalsIgnoreCase(String nombre) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}