package sistema_de_tickes;

import java.io.IOException;
import java.net.URL;
import java.util.*;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class LoginController implements Initializable {

    private final Autenticacion autenticar = new Autenticacion();

    @FXML private Button btnSalir;
    @FXML private Button btnIngresar;
    @FXML private PasswordField passContraseña;
    @FXML private TextField fldUsuario;
    @FXML private Label txtUsuario;
    @FXML private Label txtContraseña;

    // Rutas centralizadas
    private static final String RUTA_SISTEMA = "/Graficos/Sistema.fxml";
    private static final String RUTA_MENU_TECNICO = "/Graficos/MenuTecnico.fxml";
    private static final String RUTA_MENU_USUARIO = "/Graficos/MenuUsuarion.fxml";

    private static final Map<String, List<String>> PERMISOS;
    static {
        Map<String, List<String>> map = new HashMap<>();
        map.put("Administrador", Arrays.asList(RUTA_SISTEMA, RUTA_MENU_TECNICO, RUTA_MENU_USUARIO));
        map.put("Tecnico", Collections.singletonList(RUTA_MENU_TECNICO));
        map.put("Usuario", Collections.singletonList(RUTA_MENU_USUARIO));
        PERMISOS = Collections.unmodifiableMap(map);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        autenticar.agregarUsuario("admin1", "12345", "Administrador");
        autenticar.agregarUsuario("tecnico1", "123", "Tecnico");
        autenticar.agregarUsuario("usuario1", "1234", "Usuario");
    }

    @FXML
    private void eventSalir(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION,
            "Se cerrará la aplicación.", ButtonType.OK, ButtonType.CANCEL);
        alert.setTitle("Confirmación");
        alert.setHeaderText("¿Estás seguro de que quieres salir?");
        if (alert.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            Stage stage = (Stage) btnSalir.getScene().getWindow();
            stage.close();
        }
    }

    @FXML
    private void eventIngresar(ActionEvent event) {
        String usuario = fldUsuario.getText().trim();
        String contraseña = passContraseña.getText();

        if (usuario.isEmpty() || contraseña.isEmpty()) {
            mostrarMensaje(Alert.AlertType.WARNING, "Campos Vacíos",
                           "Por favor, completa todos los campos.");
            return;
        }

        String rol = autenticar.validarCredenciales(usuario, contraseña);
        if (rol != null) {
            Sesion.iniciarSesion(usuario, rol);
            mostrarMensaje(Alert.AlertType.INFORMATION, "Bienvenido",
                           "Hola " + usuario + ", has iniciado sesión como " + rol + ".");
            String rutaInicial = getRutaInicial(rol);
            navegarSegunRol(rol, rutaInicial);
        } else {
            mostrarMensaje(Alert.AlertType.ERROR, "Error de Inicio de Sesión",
                           "Usuario o contraseña incorrectos.");
        }
    }

    private String getRutaInicial(String rol) {
        switch (rol) {
            case "Administrador":
                return RUTA_SISTEMA;
            case "Tecnico":
                return RUTA_MENU_TECNICO;
            case "Usuario":
                return RUTA_MENU_USUARIO;
            default:
                return "";
        }
    }

    private void navegarSegunRol(String rol, String rutaFXML) {
        List<String> permitidas = PERMISOS.getOrDefault(rol, Collections.emptyList());
        if (!permitidas.contains(rutaFXML)) {
            mostrarMensaje(Alert.AlertType.ERROR,
                           "Acceso Denegado",
                           "No tienes permiso para ver esta pantalla.");
            return;
        }
        Stage stage = (Stage) btnIngresar.getScene().getWindow();
        cargarFXML(rutaFXML, stage);
    }

    private void cargarFXML(String ruta, Stage stage) {
    try {
        URL recurso = getClass().getResource(ruta);
        if (recurso == null) {
            System.err.println("No se encontró el archivo FXML: " + ruta);
            return;
        }
        Parent root = FXMLLoader.load(recurso);
        stage.setScene(new Scene(root));
        stage.setTitle("Sistema de Tickes");
        stage.show();
    } catch (IOException e) {
        e.printStackTrace();
    }
}

   

    private void mostrarMensaje(Alert.AlertType tipo, String titulo, String mensaje) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}