package sistema_de_tickes;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.input.MouseEvent;

import java.io.File;

public class SistemaController {

    private TextField fldNombre;
    private TextField fldVencimiento;
    private TextField fldNuevaPrioridad;

    private ComboBox<String> boxIdioma;
    private ComboBox<String> boxHorario;
    private ComboBox<String> boxPrioridad;

    private DatePicker datePickerTiempoTicket;
    private ImageView img;

    private Button btnImagen;

    @FXML private MenuButton BotonMenu;
    @FXML private MenuItem Usuarios;
    @FXML private MenuItem itemRoles;
    @FXML private MenuItem itemTicket;
    @FXML private MenuItem itemDepartamento;
    @FXML private MenuItem itemDetallesTicket;
    @FXML private MenuItem itemFlujoDeTrabajo;
    @FXML private MenuItem itemSalir;

    private ObservableList<String> prioridades = FXCollections.observableArrayList();

    public void initialize() {
        boxIdioma.setItems(FXCollections.observableArrayList("Español", "Inglés", "Francés"));
        boxHorario.setItems(FXCollections.observableArrayList("GMT-6", "GMT-5", "GMT-4", "GMT+1"));
        prioridades.addAll("Alta", "Media", "Baja");
        boxPrioridad.setItems(prioridades);
        img.setImage(null);
    }

    private void eventImagen(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar Imagen");
        fileChooser.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg", "*.gif")
        );
        Stage stage = (Stage) btnImagen.getScene().getWindow();
        File file = fileChooser.showOpenDialog(stage);
        if (file != null) {
            Image imagen = new Image(file.toURI().toString());
            img.setImage(imagen);
        }
    }

    private void agregarPrioridadAction(ActionEvent event) {
        String nuevaPrioridad = fldNuevaPrioridad.getText().trim();
        if (!nuevaPrioridad.isEmpty() && !boxPrioridad.getItems().contains(nuevaPrioridad)) {
            boxPrioridad.getItems().add(nuevaPrioridad);
            fldNuevaPrioridad.clear();
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING, "La prioridad está vacía o ya existe.", ButtonType.OK);
            alert.showAndWait();
        }
    }

    private void Registrar() {
        System.out.println("=== CONFIGURACIÓN REGISTRADA ===");
        System.out.println("Nombre Empresa: " + fldNombre.getText());
        System.out.println("Idioma: " + boxIdioma.getValue());
        System.out.println("Zona Horaria: " + boxHorario.getValue());
        System.out.println("Tiempo Ticket: " + datePickerTiempoTicket.getValue());
        System.out.println("Prioridad seleccionada: " + boxPrioridad.getValue());
        System.out.println("Vencimiento: " + fldVencimiento.getText());
        System.out.println("================================");
    }

    private void eventCancelar(ActionEvent event) {
        fldNombre.clear();
        fldVencimiento.clear();
        fldNuevaPrioridad.clear();
        boxIdioma.getSelectionModel().clearSelection();
        boxHorario.getSelectionModel().clearSelection();
        boxPrioridad.getSelectionModel().clearSelection();
        datePickerTiempoTicket.setValue(null);
        img.setImage(null);
    }

    private void eventRegresar(ActionEvent event) {
        showInfo("Regresar", "Volver a la pantalla anterior.");
    }

    private void eventUsuarios(ActionEvent event) {
        showInfo("Usuarios", "Módulo de gestión de usuarios.");
    }

    private void eventRoles(ActionEvent event) {
        showInfo("Roles", "Módulo de gestión de roles.");
    }

    private void eventTicket(ActionEvent event) {
        showInfo("Ticket", "Módulo de configuración de tickets.");
    }

    private void eventDepartamento(ActionEvent event) {
        showInfo("Departamento", "Módulo de departamentos.");
    }

    private void eventDetalleTicket(ActionEvent event) {
        showInfo("Detalles del Ticket", "Ver detalles del ticket.");
    }

    private void itemFlujoDeTrabajo(ActionEvent event) {
        showInfo("Flujo de Trabajo", "Gestión de flujos de trabajo.");
    }

    private void eventHistorial(ActionEvent event) {
        showInfo("Historial", "Consulta del historial.");
    }

    private void eventSallir(ActionEvent event) {
        Stage stage = (Stage) btnSalir.getScene().getWindow();
        stage.close();
    }

private void eventCambiarPantalla(ActionEvent event) {
 
    Alert alert = new Alert(Alert.AlertType.INFORMATION, "Funcionalidad para cambiar pantalla.");
    alert.showAndWait();
}
    private void Agregar(MouseEvent event) {
        Registrar();
    }

    private void showInfo(String titulo, String contenido) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(contenido);
        alert.showAndWait();
    }

    private Button btnSalir; 
}
