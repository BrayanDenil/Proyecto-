package Modelos;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.*;
import Modelos.Estado_Ticket;
import Modelos.Estado;

/**
 * 
 * 
 * @author denil
 */
public class Flujo_De_Trabajo_Ticket implements Serializable {
    private String nombre;
    private List<Estado> estados;
    private List<Transicion> transiciones;
    private Map<Estado, String> accionesAutomaticas;
    private Map<String, Estado> estadosPorNombre; 
    private String creadoPor;
    private LocalDateTime fechaCreacion;


    public Flujo_De_Trabajo_Ticket(String nombre, String creadoPor) {
        this.nombre = nombre;
        this.estados = new ArrayList<>();
        this.transiciones = new ArrayList<>();
        this.accionesAutomaticas = new HashMap<>();
        this.estadosPorNombre = new HashMap<>();
        this.creadoPor = creadoPor;
        this.fechaCreacion = LocalDateTime.now();
    }

    public Flujo_De_Trabajo_Ticket(String nombreFlujo, List<String> estadosSeleccionados, 
                                    Map<String, List<String>> transicionesPermitidas, 
       Map<String, String> reglasTransicion, 
       Map<String, String> accionesAutomaticas) {

        this.nombre = nombreFlujo;
        this.estados = new ArrayList<>();
        this.transiciones = new ArrayList<>();
        this.accionesAutomaticas = new HashMap<>();
        this.estadosPorNombre = new HashMap<>();
        this.creadoPor = "Sistema";  
        this.fechaCreacion = LocalDateTime.now();

       
        for (String estado : estadosSeleccionados) {
    Estado nuevoEstado = Estado.valueOf(estado); // usar el enum
    this.estados.add(nuevoEstado);
    this.estadosPorNombre.put(estado, nuevoEstado);
}

        
        for (Map.Entry<String, List<String>> entry : transicionesPermitidas.entrySet()) {
            String estadoDesde = entry.getKey();
            List<String> estadosDestino = entry.getValue();
            Estado estadoOrigen = obtenerEstadoPorNombre(estadoDesde);

            for (String estadoTo : estadosDestino) {
                Estado estadoDestino = obtenerEstadoPorNombre(estadoTo);
                if (estadoOrigen != null && estadoDestino != null) {
                    String regla = reglasTransicion.get(estadoTo); 
                    Transicion transicion = new Transicion(estadoOrigen, estadoDestino, regla);
                    this.transiciones.add(transicion);
                }
            }
        }

        for (Map.Entry<String, String> entry : reglasTransicion.entrySet()) {
            Estado estado = obtenerEstadoPorNombre(entry.getKey());
            String regla = entry.getValue();
        }
        for (Map.Entry<String, String> entry : accionesAutomaticas.entrySet()) {
            Estado estado = obtenerEstadoPorNombre(entry.getKey());
            String accion = entry.getValue();
            this.accionesAutomaticas.put(estado, accion);
        }
    }

    private Estado obtenerEstadoPorNombre(String nombre) {
        return this.estadosPorNombre.get(nombre);
    }

    
    public void agregarEstado(Estado estado) {
        estados.add(estado);
       estadosPorNombre.put(estado.name(), estado); 
    }


    public void agregarTransicion(Transicion transicion) {
        transiciones.add(transicion);
    }

    
    public void agregarAccionAutomatica(Estado estado, String accion) {
        accionesAutomaticas.put(estado, accion);
    }

    public void ejecutarAccionAutomatica(Estado estado) {
        if (accionesAutomaticas.containsKey(estado)) {
            String accion = accionesAutomaticas.get(estado);
            
            System.out.println("Ejecutando acción automática: " + accion);
        }
    }

   
    public boolean validarTransiciones() {
        for (Estado estado : estados) {
            if (!estado.esFinal()) {
                boolean tieneSalida = transiciones.stream().anyMatch(t -> t.getEstadoOrigen().equals(estado));
                if (!tieneSalida) return false;
            }
        }
        return true;
    }

 
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Estado> getEstados() {
        return estados;
    }

    public void setEstados(List<Estado> estados) {
        this.estados = estados;
    }

    public List<Transicion> getTransiciones() {
        return transiciones;
    }

    public void setTransiciones(List<Transicion> transiciones) {
        this.transiciones = transiciones;
    }

    public Map<Estado, String> getAccionesAutomaticas() {
        return accionesAutomaticas;
    }

    public void setAccionesAutomaticas(Map<Estado, String> accionesAutomaticas) {
        this.accionesAutomaticas = accionesAutomaticas;
    }

    public String getCreadoPor() {
        return creadoPor;
    }

    public void setCreadoPor(String creadoPor) {
        this.creadoPor = creadoPor;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDateTime fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    @Override
    public String toString() {
        return "Flujo_De_Trabajo_Ticket{" +
                "nombre='" + nombre + '\'' +
                ", estados=" + estados +
                ", transiciones=" + transiciones +
                ", accionesAutomaticas=" + accionesAutomaticas +
                ", creadoPor='" + creadoPor + '\'' +
                ", fechaCreacion=" + fechaCreacion +
                '}';
    }
}
