package sistema_de_tickes;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;

/**
 *
 * @author denil
 */
public class Autenticacion {
    private final HashMap<String, Usuario> usuarios = new HashMap<>();

    
    public void agregarUsuario(String usuario, String contraseña, String rol) {
        String hash = hashContraseña(contraseña);
        usuarios.put(usuario, new Usuario(hash, rol));
    }

    public String validarCredenciales(String usuario, String contraseña) {
        Usuario datos = usuarios.get(usuario);
        if (datos != null && datos.getHashContraseña().equals(hashContraseña(contraseña))) {
            return datos.getRol();
        }
        return null; 
    }

    
    private String hashContraseña(String contraseña) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(contraseña.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b)); 
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error al hacer hash de la contraseña", e);
        }
    }

    
    private static class Usuario {
        private String hashContraseña;  
        private String rol;             

       
        Usuario(String hashContraseña, String rol) {
            this.hashContraseña = hashContraseña;
            this.rol = rol;
        }

     
        public String getHashContraseña() {
            return hashContraseña;
        }

       
        public String getRol() {
            return rol;
        }
    }
}